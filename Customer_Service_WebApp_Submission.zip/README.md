
# Customer Service Booking Web Application

This project is a full-stack web application that allows users to explore services and contact customer support. Admins can manage services, news, and contact queries via a secure dashboard.

## 🛠 Tech Stack

- **Frontend:** React.js, Axios, React Router DOM
- **Backend:** Node.js, Express.js, Mongoose
- **Database:** MongoDB (with Mongoose ODM)
- **Tools:** Postman, VS Code, Git
- **Optional Deployment:** Vercel (frontend), Render (backend)

## ✨ Features

- User Registration and Login with JWT Authentication
- Secure Admin Dashboard for managing services, news, and users
- Product and Service display for customers
- Contact form to send messages to admin
- Responsive and clean UI built with React

## 📁 Folder Structure

```
MyAppProject/
├── backend/
│   ├── models/
│   ├── routes/
│   ├── server.js
│   └── package.json
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── components/
│   │   └── pages/
│   └── package.json
├── README.md
└── screenshots/
```

## 🚀 Getting Started

### Backend Setup

```bash
cd backend
npm install
# Create a .env file with MONGODB_URI and JWT_SECRET
npm start
```

### Frontend Setup

```bash
cd frontend
npm install
npm start
```

## 🧪 Usage

- Visit the home page and register/login
- Explore available services and products
- Use contact form to send a message
- Admin can login and manage dashboard content

## 🌐 Deployment (Optional)

- **Frontend:** Deploy on Vercel
- **Backend:** Deploy on Render or Cyclic
- **Database:** MongoDB Atlas

## 📸 Screenshots

Add screenshots in `screenshots/` folder and reference them here.

## 📄 License

This project is for educational purposes.
